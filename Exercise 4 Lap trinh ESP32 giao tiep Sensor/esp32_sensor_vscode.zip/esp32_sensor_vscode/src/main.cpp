#include "DHTesp.h"
#include "LiquidCrystal_I2C.h"
#include "WiFi.h"

DHTesp dhtSensor;
LiquidCrystal_I2C lcd(0x27,20,4);  // set the LCD address to 0x27 for a 16 chars and 2 line display
const int PIR_PIN = 12; //PIR sensor pin
int motion = 0;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  Serial.println("Hello, ESP32!");

  WiFi.begin("Wokwi-GUEST", "", 6);
  while (WiFi.status() != WL_CONNECTED) {
    delay(100);
    Serial.print(".");
  }
  Serial.println("WiFi Connected!");
  Serial.println("IP Address: "); 
  Serial.println(WiFi.localIP());

  pinMode(PIR_PIN, INPUT);
  
  pinMode(32, OUTPUT);
  dhtSensor.setup(15, DHTesp::DHT22); //Cấu hình cho DHT sensor
  
  lcd.init(); // initialize the lcd 
  // Print a message to the LCD.
  lcd.backlight();
  lcd.setCursor(1,0);
  lcd.print("ESP32 collecting data ...");

}

void loop() {
  // put your main code here, to run repeatedly:
  float t = dhtSensor.getTemperature();
  float h = dhtSensor.getHumidity(); 
  
  TempAndHumidity  data = dhtSensor.getTempAndHumidity();
  int temp = data.temperature;
  int humid = data.humidity;
  
  String stemp = String(temp) + "C";
  String shumid = String(humid) + "%";
  
  Serial.println("Temp: " + stemp);
  Serial.println("Humidity: " + shumid);
  Serial.println("---");

  lcd.setCursor(0,0);
  lcd.print("Temperature: " + String(temp) + "C");
  lcd.setCursor(0,1);
  lcd.print("Humidity: " + String(humid) + "%");

  motion = digitalRead(PIR_PIN);
  if(motion){
    digitalWrite(32, 1); //LED on
    Serial.println("Motion: detected");
  }
  else{
    digitalWrite(32, 0); //LED off
    Serial.println("Motion: NO");
  }
  delay(200);

  //digitalWrite(32, 1);
  //delay(100); // this speeds up the simulation
  //digitalWrite(32, 0);
  //delay(100);
}
